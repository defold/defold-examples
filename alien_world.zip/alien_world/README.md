# Alien World

Alien World is a complete game art pack to make a fantastic sci-fi platform metroidvania game in the style of the 16-bit console era. It includes everything you need, from seamless loopable backgrounds, tillable sprites, sci-fi props, some fearful enemies, mysterious NPC’s and of course a Daring Hero.

by Luis Zuno  
web: http://ansimuz.com/  
twitter: https://twitter.com/ansimuz

(Please give credit to Luis Zuno when you use the art in a game)